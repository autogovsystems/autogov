<?php
/*
 * To fake it is to stand guard over emptiness.
 * Arthur Herzog
 */
?>
