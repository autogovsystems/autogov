<?php

/**
 * Description of BPMediaBranding
 *
 * @package BuddyPressMedia
 * @subpackage Admin
 *
 * @author Gagandeep Singh <gagandeep.singh@rtcamp.com>
 * @author Joshua Abenazer <joshua.abenazer@rtcamp.com>
 */
if ( ! class_exists( 'BPMediaBranding' ) ) {

	class BPMediaBranding {

		public function __construct() {

		}
	}

}
