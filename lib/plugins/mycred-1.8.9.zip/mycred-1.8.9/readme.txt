=== myCred - Points, Rewards, Gamification, Ranks, Badges & Loyalty Plugin ===
Contributors: mycred,wpexpertsio
Tags: point, credit, loyalty program, engagement, reward
Requires at least: 4.8
Tested up to: 5.4
Stable tag: 1.8.9
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An adaptive and powerful points management system for WordPress powered websites.

== Description ==

myCRED is an adaptive points management system that lets you build a broad range of point related applications for your WordPress powered website.
Store reward systems, community leaderboards, online banking or monetizing your websites content, are a few examples of the ways myCRED is used.

= Points =

Each user on your WordPress websites gets their own point balance which you can manually [adjust](https://mycred.me/about/features/#points-management) at any time. You can use just one point balance or setup multiple types of balances. How these balances are accessed, used or shows is entirely up to you.


= Log =

Each time myCRED adds or deducts points from a user, the adjustment is [logged](https://mycred.me/about/features/#account-history) in a dedicated log, allowing your users to browse their history. The log is also used to provide you with statistics, accountability, badges, ranks and to enforce limits you might set.


= Awarding or Deducting Points Automatically =

myCRED supports a vast set of ways you can automatically give / take points from a user. Everything from new comments to store purchases. These automatic adjustments are managed by so called [Hooks](https://mycred.me/about/features/#automatic-points) which you can setup in your admin area.


= Third-party plugin Support =

myCRED supports some of the most [popular plugins](https://mycred.me/about/supported-plugins/) for WordPress like BuddyPress, WooCommerce, Jetpack, Contact Form 7 etc. To prevent to much cluttering in the admin area with settings, myCRED will only show features/settings for third-party plugins that are installed and enabled.


= Add-ons =

There is so much more to myCRED then just adjusting balances. The plugin comes with several [built-in add-ons](https://mycred.me/add-ons/) which enabled more complex features such as allowing point transfers, buying points for real money, allow payments in stores etc.


= Documentation =

You can find extensive [documentation](http://codex.mycred.me/) on everything myCRED related in the myCRED Codex. You can also find a list of [frequently asked](https://mycred.me/about/faq/) questions on the myCRED website.


= Customizations =

myCRED was not built to "do-it-all". Instead a lot of effort has been made to make the plugin as developer friendly as possible. If you need a custom feature built, you can submit a [request for a quote](https://mycred.me/customize/request-quote/) via the myCRED website.


= Code Snippets =

The most commonly asked customizations for myCRED are available as code snippets on the [myCRED website](https://mycred.me/code-snippets/), free to use by anyone.


= Support =

Support is offered on our [myCRED website](https://mycred.me/support/)  from Monday to Friday 9AM - 5PM (GMT+5). Submit [customization request](https://mycred.me/customize/request-quote/) or open a [support ticket](https://mycred.me/support/) If you have trouble with myCRED which is not described in documentation also you can consult the [online community](https://mycred.me/support/forums/) for your question. We pay myCRED Store Tokens as a reward on reporting bugs and their fixes as well. Support is not entertained here on the wordpress.org support forum or on any social media account. 


== Installation ==

= myCRED Guides =

[Chapter I - Introduction](http://codex.mycred.me/chapter-i/)

[Chapter II - Getting Started](http://codex.mycred.me/chapter-ii/)

[Chapter III - Add-ons](http://codex.mycred.me/chapter-iii/)

[Chapter IV - Premium Add-ons](http://codex.mycred.me/chapter-iv/)

[Chapter V - For Developers](http://codex.mycred.me/chapter-v/)

[Chapter VI - Reference Guides](http://codex.mycred.me/chapter-vi/)


== Frequently Asked Questions ==

You can find a list of [frequently asked questions](https://mycred.me/about/faq/) on the myCRED website.


== Screenshots ==

1. **Add-ons** - Add-ons are managed just like themes in WordPress.
2. **Edit Balances** - Administrators can edit any users balance at any time via the Users page in the admin area.
3. **Hooks** - Hooks are managed just like widgets in WordPress.
4. **Edit Log Entries** - Administrators can edit any log entry at any time via the admin area.


== Upgrade Notice ==

= 1.8.0 =
Major release(Make sure to take backup before updating)

= 1.8.1 =
Bug fixes release.

= 1.8.2 =
Bug fixes release.

= 1.8.3 =
Bug fixes release.

= 1.8.4 =
Bug fixes release.

= 1.8.4.1 =
Bug fixes release.

= 1.8.4.2 =
Bug fixes release.

= 1.8.5 =
Bug fixes release.

= 1.8.5.1 =
Bug fixes release.

= 1.8.6 =
Bug fixes release.

= 1.8.7 =
Bug fixes release.

= 1.8.8 =
Bug fixes release.

= 1.8.9 =
Bug fixes release.


== Other Notes ==

= Requirements =
* WordPress 4.8 or greater
* PHP version 5.6 or greater
* PHP mcrypt library enabled
* MySQL version 5.0 or greater

= Language Contributors =
* Swedish - Gabriel S Merovingi
* French - Chouf1 [Dan - BuddyPress France](http://bp-fr.net/)
* Persian - Mani Akhtar
* Spanish - Jose Maria Bescos [Website](http://www.ibidem-translations.com/spanish.php)
* Russian - Skladchik
* Chinese - suifengtec [Website](http://coolwp.com)
* Portuguese (Brazil) - Guilherme
* Japanese - Mochizuki Hiroshi


== Changelog ==

= 1.8.9 =
NEW - Introduce a new filter mycred_update_total_balance.
FIX - Rank display setting issues.
FIX - View content hook limit not working properly.
FIX - Buycred maximum limit not working. 
FIX - myCred ranks show in BBPress profile and topic post even the user is excluded from the point type.
FIX - Badges not displaying in BBPress profile even check show all badges.
FIX - BuyCred Payment transactions visible in recent comments section.
TWEAK - Improvement in mycred_my_ranks shortcode.
TWEAK - Buycred shows proper error messages.

= 1.8.8 =
NEW - Introduced myCred membership.
NEW - Added support in badge for specific link click and gravity form.
TWEAK - Added notice for meta key to avoid any conflicts.
FIX - leaderboard "current" attribute was not working.
FIX - myCred ranks show in BuddyPress profile even the user is excluded from the point type.
FIX - "number" attribute was not working in stats related shortcodes.
FIX - Errors in mycred_get_ranks function.
FIX - Unselected point types also appear in myCred Wallet Widget.
FIX - Four-digit points value not working in remote API.
FIX - MYSQL and MariaDB syntax error in their newer versions.

= 1.8.7 =
NEW - Introduce a new action hook mycred_after_badge_assign.
FIX - Placeholder attribute not working in mycred_transfer shortcode.

= 1.8.6 =
NEW - Introduce a new shortcode [mycred_my_balance_converted].
NEW - Introduce a new template tag %coupon_code%.
TWEAK - Avoid duplicate database calls in get_log_table().
TWEAK - Language support in [mycred_hook_table] shortcode.
FIX - [mycred_buy] shortcode always get default point type settings.
FIX - HTML format issue in [mycred_buy_form] shortcode.
FIX - Remove badge related PHP warnings.
FIX - %order_id% template tag does not render in myCRED email.
FIX - %transfer_message% template tag does not render in myCRED email.

= 1.8.5.1 =
FIX - myCRED Statistics add-on related shortcodes.
FIX - myCRED Leaderbard cache issue.
TWEAK - Database optimization.

= 1.8.5 =
NEW - Added "to" attribute in Leaderboard shortcode.
NEW - Added filter "mycred_show_custom_coupon_value" for coupon value.
FIX - myCRED Leaderboard widget notices.
FIX - Typo fix in BuddyPress hook.
FIX - Coupon success message not showing in custom point types.
FIX - Incorrect point type in coupon notification.
FIX - Ranks not being assigned based on Total Balance.
FIX - Set default point type in ctype attribute in [mycred_users_of_all_ranks] shortcode.
FIX - [mycred_hook_table] this shortcode showing only 1 content hook at a time.
FIX - Emails that are stored in draft are also being sent.
FIX - Template tags are not being rendered in email Notices.
FIX - Admin not able to select ranks "manual mode" from settings.
FIX - Admin not able to assign ranks when "manual mode" is enabled.
FIX - Errors in [mycred_email_subscriptions] shortcode.
FIX - Transfer Message showing as "-" in log.
FIX - myCRED Cache not deleting.
FIX - When deleting a BuddyPress Activity adds a "Profile Comment Delete" log.
FIX - Assign users badge from badge edit page.
FIX - "Not in" operator not passing in query_log.
FIX - Show main image in [mycred_my_badges] shortcode if level image is not set.

= 1.8.4.2 =
FIX - myCRED hooks not adding on other point types.
FIX - option_id name not calling for other point types.

= 1.8.4.1 =
FIX - myCRED hooks not saving.
FIX - setCookie function error when adding new hook.

= 1.8.4 =
NEW - Introduce a new filter “mycred_option_id” for manipulating hooks.
NEW - Add new action "mycred_pref_hooks" on mycred hooks page
TWEAK - Limits are showing for Approved comments hook in [mycred_hook_table] shortcode.
FIX - Sell content undefined offset in Backend Pages & Posts.
FIX - mycred_buy shortcode Undefined variable: post.
FIX - Bitpay 404 page redirect.
FIX - BuyCred Gateway error message no gateway available.
FIX - myCred Email accept only ARRAY value in "get_subject" function.
FIX - Incorrect log table name in multisite when central logging is enabled.
FIX - strpos depreciated behavior.
FIX - Coupon expiration before date.
FIX - "Total in Points" value show in both Cart & Checkout page when you select "Show in Cart and on Checkout Page" in WooCommerce myCRED Gateway.

= 1.8.3 =
FIX - Fixed Woocommerce checkout errors.
FIX - Fixed get_users_balance function.
FIX - Fixed typo error in bbPress hook.
NEW - Added new feature to copy to clipboard referral link in BuddyPress profile page

= 1.8.2 =
FIX - [mycred_best_user] shortcode fixed.
FIX - Post related template tags fixed.
FIX - Sell content related issue fixed.
IMPROVEMENT - Added check for existing logs getting disappeared.

= 1.8.1 =
FIX - [mycred_my_balance] shortcode fixed.
FIX - [mycred_total_balance] shortcode fixed.
FIX - rank related issues fixed.

= 1.8 =
NEW - Added new mycred_over_hook_limit filter for adjusting hook limit checks.
NEW - Added new MYCRED_RANK_KEY constant which can be used to whitelabel ranks.
NEW - Added new MYCRED_COUPON_KEY constant which can be used to whitelabel coupons.
NEW - Added new MYCRED_BADGE_KEY constant which can be used to whitelabel badges.
NEW - Added new MYCRED_EMAIL_KEY constant with can be used to whitelabel email notifications.
NEW - Added new MYCRED_BUY_KEY constant with can be used to whitelabel pending buyCRED payments.
NEW - Added new MYCRED_ENABLE_SHORTCODES constant in cases where myCRED shortcodes needs to be disabled.
NEW - Updated the Email Notifications add-on to version 1.4 with support for custom instances, multiple point types / notice and introduced the new myCRED_Email object.
NEW - Updated the buyCRED add-on which now has improved checkout process. 
NEW - Added the option to set a custom gateway logo for all built-in payment gateways.
NEW - Updated the mycred_load_coupon shortcode to show an error message when an invalid coupon is used.
NEW - Added new Anniversary hook allowing you to reward users for each year they are a member on your website.
NEW - Added new MYCRED_ENABLE_HOOKS constant to disable hooks completely.
NEW - Added support for Multi Network setups.
NEW - Added new mycred_add_post_meta(), mycred_get_post_meta(), mycred_update_post_meta() and mycred_delete_post_meta() functions in order to add support for the Master Template feature on multisites.
NEW - Added support for multiple point types in leaderboards.
NEW - The leaderboard shortcode can now be setup to render results based on multiple point types.
NEW - Added caching of log and leaderboard queries.
NEW - Added new filter to allow adjustments to the reference used for publishing and deleting content hooks.
NEW - Added new mycred_give_run filter to control if the mycred_give shortcode should run or not.
TWEAK - Moved hooks to /includes/hooks/ and third-party hooks to /includes/hooks/external/.
TWEAK - Implemented the use of $mycred_log_table global throughout the plugin.
TWEAK - Improved Multisite support.
TWEAK - When a user jumps more than one badge level in a single instance, we want to make sure he gets rewarded for each level (if rewards is set).
TWEAK - Corrected codex urls for functions and shortcodes throughout the plugin.
TWEAK - Added support to whitelabel shortcodes.
TWEAK - Added new MYCRED_SHOW_PREMIUM_ADDONS constant to hide all mentions of premium add-ons in myCRED.
TWEAK - BuddyPress fixed issue related to points ignoring limit on adding to favorites
TWEAK - Optimized search the search for log entries
TWEAK - issue related to email not getting send on transfer in and out triggers in transfer addon
TWEAK - Rank excerpt fix


= Previous Versions =
https://mycred.me/support/changelog/