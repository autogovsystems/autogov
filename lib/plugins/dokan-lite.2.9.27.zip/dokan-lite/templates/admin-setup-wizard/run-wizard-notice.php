<div id="message" class="updated dokan-message">
    <p><?php _e( '<strong>Welcome to Dokan</strong> &#8211; You&lsquo;re almost ready to start selling :)', 'dokan-lite' ); ?></p>
    <p class="submit"><a href="<?php echo esc_url( admin_url( 'admin.php?page=dokan-setup' ) ); ?>" class="button-primary"><?php _e( 'Run the Setup Wizard', 'dokan-lite' ); ?></a></p>
</div>
