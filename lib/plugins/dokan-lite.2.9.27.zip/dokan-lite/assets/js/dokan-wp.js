dokanWebpack([3],{

/***/ 191:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _hooks = __webpack_require__(37);

dokan.wpPackages = {
    hooks: (0, _hooks.createHooks)()
};

/***/ })

},[191]);