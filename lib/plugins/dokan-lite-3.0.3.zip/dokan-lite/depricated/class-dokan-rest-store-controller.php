<?php

use WeDevs\Dokan\REST\StoreController;

class Dokan_REST_Store_Controller extends StoreController {}
