<?php

use WeDevs\Dokan\Walkers\TaxonomyDropdown\DokanTaxonomyWalker as DokanTaxWalker;

class DokanTaxonomyWalker extends DokanTaxWalker {}
