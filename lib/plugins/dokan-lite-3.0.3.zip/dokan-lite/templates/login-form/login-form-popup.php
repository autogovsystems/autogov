<div class="white-popup dokan-login-form-popup-wrapper" id="dokan-login-form-popup">
    <?php dokan_login_form( array( 'id' => 'dokan-login-form-popup-form' ), true ); ?>
</div>
