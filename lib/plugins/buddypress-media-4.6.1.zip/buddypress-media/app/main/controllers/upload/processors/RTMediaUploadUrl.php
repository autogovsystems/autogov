<?php
/**
 * Handle media upload from URL.
 *
 * @package rtMedia
 */

/**
 * Class to handle media upload from URL.
 *
 * @author joshua
 */
class RTMediaUploadUrl {
	// todo:delete if not used anywhere.
}
