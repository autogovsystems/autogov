<?php
/**
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 *
 * @package    rtMedia
 */

/**
 * Class for BPMedia import
 *
 * @author saurabh
 */
class BPMediaBPActivityPlusImporter extends BPMediaImporter {

	/**
	 * BPMediaBPActivityPlusImporter constructor.
	 */
	public function __construct() { // phpcs:ignore Generic.CodeAnalysis.UselessOverridingMethod.Found
		parent::__construct();
	}
}
