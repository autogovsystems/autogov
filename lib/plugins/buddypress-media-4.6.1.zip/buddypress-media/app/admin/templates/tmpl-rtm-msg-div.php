<?php
/**
 * Displays Message Div.
 *
 * @package rtMedia
 */

?>
<div class="{{data.class}}" id="{{data.id}}">
	<p>{{data.msg}}</p>
</div>
