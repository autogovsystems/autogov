<?php
/**
 * Displays image tag.
 *
 * @package rtMedia
 */

?>
<# if(data.class && '' !== data.class){ #>
	<img class="bpm-ajax-loader" src="{{data.src}}" /> <strong>{{data.norefresh}}</strong>
<# } else { #>
	<img style="margin: 0 0 0 10px" src="{{data.src}}" />
<# } #>
