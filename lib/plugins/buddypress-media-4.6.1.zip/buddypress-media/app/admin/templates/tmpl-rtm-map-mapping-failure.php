<?php
/**
 * Display mapping fail message div.
 *
 * @package rtMedia
 */

?>
<div class="map_mapping_failure">{{map_data.msg}}</div>
